const dialog = document.querySelector("dialog");
const showButton = document.querySelector("dialog + button");
const closeButton = document.querySelector("dialog button");

// "Show the dialog" button opens the dialog modally
showButton.addEventListener("click", function() {
  dialog.showModal();
});

// "Close" button closes the dialog
closeButton.addEventListener("click", function() {
  dialog.close();
});
